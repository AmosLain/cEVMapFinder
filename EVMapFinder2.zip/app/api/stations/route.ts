import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

import { demoStations } from "@/lib/demoStations";
import type { Station } from "@/lib/types";

function jsonNoStore(body: any, init?: { status?: number }) {
  const res = NextResponse.json(body, { status: init?.status ?? 200 });
  res.headers.set(
    "Cache-Control",
    "no-store, no-cache, must-revalidate, proxy-revalidate"
  );
  res.headers.set("Pragma", "no-cache");
  res.headers.set("Expires", "0");
  return res;
}

const TIMEOUT_MS = 12000;

function mapOcmToStation(item: Record<string, unknown>): Station {
  const ap = item.AddressInfo as Record<string, unknown> | undefined;
  const conns = item.Connections as Record<string, unknown>[] | undefined;
  const op = item.OperatorInfo as Record<string, unknown> | undefined;

  let power: string | undefined;
  if (conns && conns.length > 0) {
    const kw = conns
      .map((c) => (c.PowerKW as number | undefined) ?? 0)
      .filter((n) => Number.isFinite(n))
      .sort((a, b) => b - a)[0];
    if (kw && kw > 0) power = `${kw} kW`;
  }

  const lat = (ap?.Latitude as number | undefined) ?? null;
  const lng = (ap?.Longitude as number | undefined) ?? null;

  return {
    id: String(item.ID ?? crypto.randomUUID()),
    name: (ap?.Title as string | undefined) ?? "Charging Station",
    address: (ap?.AddressLine1 as string | undefined) ?? undefined,
    city: (ap?.Town as string | undefined) ?? undefined,
    country: (ap?.Country?.ISOCode as string | undefined) ?? undefined,
    lat: lat ?? undefined,
    lng: lng ?? undefined,
    operator: (op?.Title as string | undefined) ?? undefined,
    power,
  } as Station;
}

function parseNum(v: string | null) {
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

async function fetchWithTimeout(url: string) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      cache: "no-store",
    });
    return res;
  } finally {
    clearTimeout(t);
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);

    const lat = parseNum(searchParams.get("lat"));
    const lng = parseNum(searchParams.get("lng"));

    // אם אין מיקום — ניפול לדמו/נייטרלי (לא נשבור SSR/SEO)
    if (lat == null || lng == null) {
      return jsonNoStore({
        stations: demoStations,
        meta: { source: "default" },
      });
    }

    const key = process.env.OPEN_CHARGE_MAP_API_KEY;
    if (!key) {
      // בלי מפתח — עדיין מחזירים משהו יציב
      return jsonNoStore({
        stations: demoStations,
        meta: { source: "gps", note: "Missing OPEN_CHARGE_MAP_API_KEY" },
      });
    }

    const radiusKm = 50;

    const url =
      `https://api.openchargemap.io/v3/poi/` +
      `?output=json&latitude=${encodeURIComponent(String(lat))}` +
      `&longitude=${encodeURIComponent(String(lng))}` +
      `&distance=${encodeURIComponent(String(radiusKm))}` +
      `&distanceunit=KM&maxresults=100&compact=true&verbose=false` +
      `&key=${encodeURIComponent(key)}`;

    const res = await fetchWithTimeout(url);

    if (!res.ok) {
      return jsonNoStore(
        {
          stations: demoStations,
          meta: { source: "gps", note: `OCM error ${res.status}` },
        },
        { status: 200 }
      );
    }

    const raw = (await res.json()) as unknown;
    const items = Array.isArray(raw) ? raw : [];
    const stations = items.map((it) => mapOcmToStation(it as any));

    return jsonNoStore({
      stations,
      meta: { source: "gps", lat, lng, radiusKm },
    });
  } catch (e: any) {
    return jsonNoStore(
      { stations: demoStations, meta: { source: "default", error: e?.message } },
      { status: 200 }
    );
  }
}