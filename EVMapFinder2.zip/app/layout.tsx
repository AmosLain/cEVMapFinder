import type { Metadata } from "next";
import "./globals.css";

const SITE =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ||
  "https://www.evmapfinder.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: "EVMapFinder — Find EV Charging Stations Near You",
  description:
    "Search and discover electric vehicle charging stations. Filter by location, power type, and network. Find the nearest EV charger with one click.",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "EVMapFinder — Find EV Charging Stations Near You",
    description:
      "Discover EV charging stations near you. Search by city, name, or network.",
    type: "website",
    url: SITE,
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}