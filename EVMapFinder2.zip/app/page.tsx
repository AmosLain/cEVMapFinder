"use client";

export const dynamic = "force-dynamic";

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import type { Station } from "@/lib/types";
import { haversineKm } from "@/lib/haversine";
import StationCard from "@/components/StationCard";
import Pagination from "@/components/Pagination";
import SearchBar from "@/components/SearchBar";
import StatusBar from "@/components/StatusBar";

const PAGE_SIZE = 12;

type GeoState = {
  lat: number;
  lng: number;
} | null;

export default function HomePage() {
  const [allStations, setAllStations] = useState<Station[]>([]);
  const [loading, setLoading] = useState(false);
  const [geoLoading, setGeoLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [geo, setGeo] = useState<GeoState>(null);
  const [geoStatus, setGeoStatus] = useState<string | null>(null);

  const [page, setPage] = useState(1);

  const hasLocation = !!geo;

  // Debounce search query (client only)
  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      setDebouncedQuery(query.trim());
      setPage(1);
    }, 250);

    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [query]);

  const fetchStations = useCallback(
    async (nextGeo: GeoState) => {
      setLoading(true);
      setError(null);

      const params = new URLSearchParams();
      if (nextGeo?.lat != null && nextGeo?.lng != null) {
        params.set("lat", String(nextGeo.lat));
        params.set("lng", String(nextGeo.lng));
      }

      const url = `/api/stations${
        params.size > 0 ? "?" + params.toString() : ""
      }`;

      try {
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) throw new Error(`Server error ${res.status}`);
        const data = await res.json();

        const stations: Station[] = Array.isArray(data?.stations)
          ? data.stations
          : [];

        setAllStations(stations);
      } catch (e: any) {
        setError(e?.message || "Failed to load stations");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Load once on mount (no GPS auto-request)
  useEffect(() => {
    fetchStations(null);
  }, [fetchStations]);

  const handleFindNearMe = useCallback(() => {
    if (!navigator.geolocation) {
      setGeoStatus("Geolocation is not supported by this browser");
      return;
    }

    setGeoLoading(true);
    setGeoStatus("Requesting location permission…");

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const next = { lat, lng };

        setGeo(next);
        setGeoStatus("Location acquired");
        setGeoLoading(false);

        fetchStations(next);
      },
      () => {
        setGeo(null);
        setGeoStatus("Location denied — using fallback");
        setGeoLoading(false);

        fetchStations(null);
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
    );
  }, [fetchStations]);

  const computed = useMemo(() => {
    // optional: filter client side by query
    const q = debouncedQuery.toLowerCase();

    let list = allStations;

    if (q) {
      list = list.filter((s) => {
        const hay = [
          s.name,
          s.address,
          s.city,
          s.country,
          s.operator,
          s.power,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return hay.includes(q);
      });
    }

    // If we have geo, compute distance + sort
    if (geo?.lat != null && geo?.lng != null) {
      list = list
        .map((s) => {
          if (s.lat == null || s.lng == null) return s;
          const d = haversineKm(geo.lat, geo.lng, s.lat, s.lng);
          return { ...s, distanceKm: d };
        })
        .sort((a, b) => (a.distanceKm ?? 1e9) - (b.distanceKm ?? 1e9));
    }

    const total = list.length;
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const safePage = Math.min(page, totalPages);

    const start = (safePage - 1) * PAGE_SIZE;
    const end = start + PAGE_SIZE;

    return {
      list,
      pageItems: list.slice(start, end),
      total,
      totalPages,
      safePage,
    };
  }, [allStations, debouncedQuery, geo, page]);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-50">
      <div className="max-w-5xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight">EVMapFinder</h1>
          <p className="text-slate-400 mt-2">
            Find EV charging stations near you — worldwide.
          </p>
        </div>

        <SearchBar
          value={query}
          onChange={setQuery}
          onFindNearMe={handleFindNearMe}
          geoLoading={geoLoading}
        />

        <div className="mt-4">
          <StatusBar
            loading={loading}
            error={error}
            total={computed.total}
            geoStatus={geoStatus}
            hasLocation={hasLocation}
          />
        </div>

        <div className="grid gap-4 mt-6">
          {computed.pageItems.map((st) => (
            <StationCard key={st.id} station={st} />
          ))}
        </div>

        <Pagination
          currentPage={computed.safePage}
          totalPages={computed.totalPages}
          onPageChange={setPage}
        />
      </div>
    </main>
  );
}